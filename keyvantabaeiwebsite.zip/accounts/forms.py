from django import forms
from django.contrib.auth.models import User


class userloginform(forms.Form):
	username = forms.CharField(label='نام کاربری',max_length=30,
							   widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'نام کاربری'}))
	password = forms.CharField(label='رمز عبور',max_length=50,
							   widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'رمز عبور'}))


class userregistrationform(forms.Form):
	username = forms.CharField(label='نام کاربری', max_length=30,
							   widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'نام کاربری'}))
	email = forms.EmailField(label='رایانامه', max_length=50,
							 widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'رایانامه'}))
	password1 = forms.CharField(label='رمز عبور', max_length=50,
								widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'رمز عبور'}))
	password2 = forms.CharField(label='باز نویسی رمز عبور', max_length=50, widget=forms.PasswordInput(
		attrs={'class': 'form-control', 'placeholder': 'بازنویسی رمز عبور '}))

	def clean_email(self):
		# Check that email is not duplicate
		username = self.cleaned_data["username"]
		email = self.cleaned_data["email"]
		users = User.objects.filter(email__iexact=email).exclude(username__iexact=username)
		name = User.objects.filter(username__iexact=username).exclude(email__iexact=email)
		if users:
			raise forms.ValidationError(" این رایانامه از پیش نام تویسی شده است")
		if name:
			raise forms.ValidationError(" این نام از پیش نام تویسی شده است")
		return email

	def clean_password2(self):
		p1 = self.cleaned_data['password1']
		p2 = self.cleaned_data['password2']

		if p1 != p2:
			raise forms.ValidationError('رمز عبور یکسان وارد نشده است')
		return p1
