from  django.urls import path
from . import  views

app_name='accounts'

urlpatterns=[
    path('login/',views.login_form,name='userlogin'),
    path('register/',views.register_form,name='userregister'),
    path('logout/',views.logout_form,name='userlogout')
]