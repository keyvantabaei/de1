from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import authenticate,login,logout
from .forms import userloginform,userregistrationform
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.models import User
from django import forms
# Create your views here.
def login_form(request):
    if(request.method=="POST"):
        form=userloginform(request.POST)
        if(form.is_valid()):
            username=form.cleaned_data['username']
            password=form.cleaned_data['password']
            user=authenticate(request,username=username,password=password)
            if user is not None:
                login(request, user)
                messages.success(request,'you have logged in successfully .','success')
                return redirect('geant4:geant4dataindex')
            else:
                messages.error(request,'invalid username or password.','danger')
                return render(request,'accounts/login.html',{'form':form})
    else:
        form=userloginform()
        return render(request,'accounts/login.html',{'form':form})

def register_form(request):
    if(request.method=='POST'):
        form = userregistrationform(request.POST)
        if (form.is_valid()):
            data = form.cleaned_data
            User.objects.create_user(data['username'],data['email'],data['password1'])
            messages.success(request,'       عزیز ثبت نام شما با موفقیت انجام شد        '+data['username'],'success')
            return redirect('geant4:geant4dataindex')
        else:
            return render(request, 'accounts/register.html', {'form': form})
    else:
        form=userregistrationform()
        return render(request,'accounts/register.html',{'form':form})

def logout_form(request):
    logout(request)
    messages.success(request,'شما از حسابتان خارج شدید' , 'success')
    return redirect('geant4:geant4dataindex')