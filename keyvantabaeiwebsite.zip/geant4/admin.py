from django.contrib import admin
from .models import geant4
admin.site.register(geant4)
# Register your models here.
class Geant4Admin(admin.ModelAdmin):
    prepopulated_fields = {'slug':('title',)}