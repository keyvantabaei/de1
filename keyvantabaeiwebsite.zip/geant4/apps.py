from django.apps import AppConfig


class Geant4Config(AppConfig):
    name = 'geant4'
