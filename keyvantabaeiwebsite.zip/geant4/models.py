from django.db import models
from django.contrib.auth.admin import User
from django.urls import reverse
from ckeditor.fields import RichTextField
from ckeditor_uploader.fields import RichTextUploadingField
class geant4(models.Model):
    title = models.CharField(max_length=120)
    slug = models.SlugField(max_length=120, default='')
    body =RichTextUploadingField() # models.TextField()
    writer = models.ForeignKey(User, on_delete=models.CASCADE, default='')
    created = models.DateTimeField(auto_now=True, auto_now_add=False)
    updated = models.DateTimeField(auto_now=False, auto_now_add=True)

    def get_absolute_url(self):
      return reverse('geant4:g4_detail',args=[self.id,self.slug])
    def __str__(self):
        return self.title