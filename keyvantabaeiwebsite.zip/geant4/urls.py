from django.urls import path
from . import  views

app_name='geant4'
urlpatterns=[
    path('',views.geant4dataindex,name='geant4dataindex'),
    path('<int:id>/<slug:slug>/',views.geant4_detail,name='g4_detail')
]