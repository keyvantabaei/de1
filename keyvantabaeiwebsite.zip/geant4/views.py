from django.shortcuts import render
from  .models import geant4
# Create your views here.
def geant4dataindex(request):
    data=geant4.objects.all()
    # data=geant4.objects.filtter(title='title') #emkan filter haye behtar ham hast ba sakhtan manager
    return render(request,'geant4/geant4dataindex.html',{'data':data})
def geant4_detail(request,id,slug):
    data=geant4.objects.get(id=id,slug=slug)
    return  render(request,'geant4/detail.html',{'data':data})