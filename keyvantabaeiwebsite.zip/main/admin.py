from django.contrib import admin
from .models import mainmodel
admin.site.register(mainmodel)
# Register your models here.
