from django.db import models
from django.contrib.auth.admin import User
class mainmodel(models.Model):
	title = models.CharField(max_length=120)
	slug = models.SlugField(max_length=120, default='')
	description = models.TextField()  # models.TextField()
	image=models.ImageField(upload_to='mainimage')
	writer = models.ForeignKey(User, on_delete=models.CASCADE, default='')
	created = models.DateTimeField(auto_now=True, auto_now_add=False)
	updated = models.DateTimeField(auto_now=False, auto_now_add=True)
	def imagepath(self):
		return self.image.url

# Create your models here.
