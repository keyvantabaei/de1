from django.shortcuts import render
from .models import mainmodel

# Create your views here.
def showitems(request):
	data = mainmodel.objects.all()
	print(data)
	return render(request, 'main/index.html', {'data': data})
# # Create your views here.
